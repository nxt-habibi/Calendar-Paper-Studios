package com.paperstudios.calendar;

import android.app.Activity;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.content.Context;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        webView.addJavascriptInterface(new Haptics(this), "PaperHaptics");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }
    public static class Haptics {
        private final Context context;
        Haptics(Context c){ context=c; }
        @android.webkit.JavascriptInterface public void vibrate(int ms){
            Vibrator v=(Vibrator)context.getSystemService(Context.VIBRATOR_SERVICE);
            if(v!=null && v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(ms,VibrationEffect.DEFAULT_AMPLITUDE));
        }
    }
    @Override public void onBackPressed(){ if(webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
