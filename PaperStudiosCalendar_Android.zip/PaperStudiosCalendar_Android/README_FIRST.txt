PAPER STUDIOS CALENDAR - ANDROID PROJECT

This folder is a ready Android Studio project containing the repaired Calendar HTML app.

EASIEST WAY TO BUILD:
1. Install Android Studio on a Windows/Mac/Linux computer.
2. Open this entire folder in Android Studio.
3. Let Gradle sync/download Android components.
4. Build > Build APK(s).
5. Android Studio will give you the APK file.

PLAY STORE:
Use Build > Generate Signed Bundle / APK > Android App Bundle (AAB).
You will need to create a signing key for Play Store publishing.

IMPORTANT:
- The Play Store icon is intentionally left for you to add later.
- The app currently loads the supplied single HTML file locally.
- Notifications that work after the app is completely closed still require a native notification implementation; the HTML reminder system works while the app is running.
